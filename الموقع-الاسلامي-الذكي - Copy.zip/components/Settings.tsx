
import React from 'react';
import { UserData, Page } from '../types';

interface Props {
  userData: UserData;
  setUserData: React.Dispatch<React.SetStateAction<UserData>>;
  onNavigate: (page: Page) => void;
}

const Settings: React.FC<Props> = ({ userData, setUserData }) => {
  const isDark = userData.themeColor === 'dark';

  return (
    <div className="space-y-8 pb-12 animate-in fade-in duration-700">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-black text-[var(--gold)]">الإعدادات</h2>
        <div className="w-16 h-1.5 bg-[var(--gold)]/30 mx-auto mt-4 rounded-full"></div>
      </div>

      <div className="space-y-4">
        {/* Theme Toggles */}
        <div className={`glass-panel p-8 rounded-[2.5rem] border border-[var(--gold)]/20 shadow-lg ${isDark ? 'bg-white/5' : ''}`}>
          <h4 className="font-black text-xl mb-6 text-[var(--gold)]">المظهر</h4>
          <div className="flex gap-4">
            {['white', 'dark'].map((t) => (
              <button 
                key={t}
                onClick={() => setUserData(prev => ({ ...prev, themeColor: t as any }))}
                className={`flex-1 py-4 rounded-2xl border-2 font-black transition-all ${
                  userData.themeColor === t 
                  ? 'border-[var(--gold)] bg-[var(--gold)]/10' 
                  : 'border-black/5 hover:border-[var(--gold)]/20'
                }`}
              >
                {t === 'white' ? 'نهاري' : 'ليلي'}
              </button>
            ))}
          </div>
        </div>

        {/* Khatmah Goal */}
        <div className={`glass-panel p-8 rounded-[2.5rem] border border-[var(--gold)]/20 shadow-lg ${isDark ? 'bg-white/5' : ''}`}>
          <h4 className="font-black text-xl mb-2 text-[var(--gold)]">جدول الختمة</h4>
          <p className="text-[10px] opacity-40 font-bold uppercase mb-6">حدد عدد الصفحات التي تود قراءتها يومياً</p>
          <div className="flex items-center gap-4 bg-black/5 p-4 rounded-2xl">
            <span className="text-xs font-black">عدد الصفحات:</span>
            <input 
              type="number" 
              min="0" 
              max="604"
              value={userData.khatmah.pagesPerDay}
              onChange={(e) => {
                const val = parseInt(e.target.value);
                setUserData(prev => ({
                  ...prev, 
                  khatmah: { ...prev.khatmah, pagesPerDay: isNaN(val) ? 0 : val }
                }));
              }}
              className="bg-white border-2 border-[var(--gold)]/30 rounded-xl px-4 py-2 text-sm font-black w-24 outline-none text-black"
            />
          </div>
        </div>
        
        {/* Info Card */}
        <div className={`glass-panel p-6 rounded-[2rem] border border-[var(--gold)]/10 text-center ${isDark ? 'bg-white/5 opacity-50' : 'bg-black/5 opacity-50'}`}>
          <p className="text-[10px] font-bold">يتم حساب مواقيت الصلاة تلقائياً بدقة عالية بناءً على موقعك الجغرافي الحالي.</p>
        </div>
      </div>
    </div>
  );
};

export default Settings;
