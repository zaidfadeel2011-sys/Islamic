
import { PrayerTimings } from '../types';

export const fetchPrayerTimes = async (lat: number, lon: number): Promise<PrayerTimings> => {
  const response = await fetch(`https://api.aladhan.com/v1/timings?latitude=${lat}&longitude=${lon}&method=4`);
  const data = await response.json();
  return data.data.timings;
};

export const getNextPrayer = (timings: PrayerTimings) => {
  const now = new Date();
  const prayerNames: (keyof PrayerTimings)[] = ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];
  
  const prayersWithDates = prayerNames.map(name => {
    const [hours, minutes] = timings[name].split(':').map(Number);
    const prayerDate = new Date();
    prayerDate.setHours(hours, minutes, 0, 0);
    return { name, date: prayerDate };
  });

  let next = prayersWithDates.find(p => p.date > now);

  if (!next) {
    // إذا انتهت صلوات اليوم، فالصلاة القادمة هي فجر الغد
    const [hours, minutes] = timings.Fajr.split(':').map(Number);
    const tomorrowFajr = new Date();
    tomorrowFajr.setDate(tomorrowFajr.getDate() + 1);
    tomorrowFajr.setHours(hours, minutes, 0, 0);
    next = { name: 'Fajr', date: tomorrowFajr };
  }

  const diff = next.date.getTime() - now.getTime();
  const h = Math.floor(diff / (1000 * 60 * 60));
  const m = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
  const s = Math.floor((diff % (1000 * 60)) / 1000);

  const prayerAr: Record<string, string> = {
    Fajr: 'الفجر',
    Dhuhr: 'الظهر',
    Asr: 'العصر',
    Maghrib: 'المغرب',
    Isha: 'العشاء'
  };

  return {
    name: prayerAr[next.name],
    time: timings[next.name],
    countdown: `${h}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`
  };
};
