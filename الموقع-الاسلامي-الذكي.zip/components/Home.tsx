
import React, { useState, useEffect } from 'react';
import { UserData, PrayerTimings, Page } from '../types';
import { getNextPrayer } from '../services/prayerService';

const PAGE_METADATA_URL = "https://api.alquran.cloud/v1/page";

interface Props {
  userData: UserData;
  setUserData: React.Dispatch<React.SetStateAction<UserData>>;
  prayerTimings: PrayerTimings | null;
  onNavigate: (page: Page) => void;
  onWirdClick: (page: number) => void;
}

const Home: React.FC<Props> = ({ userData, setUserData, prayerTimings, onNavigate, onWirdClick }) => {
  const [nextPrayer, setNextPrayer] = useState<any>(null);
  const [hijriDate, setHijriDate] = useState<string>("");
  const [wirdInfo, setWirdInfo] = useState<{startSurah: string, startAyah: number, endSurah: string, endAyah: number} | null>(null);

  const isDark = userData.themeColor === 'dark';

  useEffect(() => {
    const today = new Date();
    const formatter = new Intl.DateTimeFormat('ar-SA-u-ca-islamic', { day: 'numeric', month: 'long', year: 'numeric' });
    setHijriDate(formatter.format(today));

    const fetchWirdDetails = async () => {
      try {
        const startRes = await fetch(`${PAGE_METADATA_URL}/${userData.khatmah.currentPage}/quran-uthmani`);
        const startData = await startRes.json();
        const startAyahObj = startData.data.ayahs[0];
        
        const endPageNum = Math.min(604, userData.khatmah.currentPage + Math.max(0, userData.khatmah.pagesPerDay - 1));
        const endRes = await fetch(`${PAGE_METADATA_URL}/${endPageNum}/quran-uthmani`);
        const endData = await endRes.json();
        const endAyahObj = endData.data.ayahs[endData.data.ayahs.length - 1];

        setWirdInfo({
          startSurah: startAyahObj.surah.name,
          startAyah: startAyahObj.numberInSurah,
          endSurah: endAyahObj.surah.name,
          endAyah: endAyahObj.numberInSurah
        });
      } catch (e) {
        console.error("Failed to fetch wird info");
      }
    };
    fetchWirdDetails();

    if (!prayerTimings) return;
    const interval = setInterval(() => setNextPrayer(getNextPrayer(prayerTimings)), 1000);
    return () => clearInterval(interval);
  }, [prayerTimings, userData.khatmah.currentPage, userData.khatmah.pagesPerDay]);

  const advanceWird = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (userData.khatmah.pagesPerDay === 0) return;
    setUserData(prev => ({
      ...prev,
      khatmah: {
        ...prev.khatmah,
        currentPage: Math.min(604, prev.khatmah.currentPage + prev.khatmah.pagesPerDay),
        totalReadPages: prev.khatmah.totalReadPages + prev.khatmah.pagesPerDay,
        lastReadDate: new Date().toDateString(),
        isCompletedToday: true
      }
    }));
    if (navigator.vibrate) navigator.vibrate(50);
  };

  return (
    <div className={`space-y-6 animate-in fade-in slide-in-from-bottom-6 duration-700 ${isDark ? 'text-white' : 'text-[var(--text-main)]'}`}>
      <div className="text-center py-2">
        <h3 className="font-black text-xl mb-1">{hijriDate}</h3>
        <p className={`text-[10px] font-bold uppercase tracking-[0.2em] ${isDark ? 'text-white' : 'opacity-40'}`}>الورد اليومي</p>
      </div>

      <div className="rounded-[2.5rem] p-8 relative overflow-hidden gold-card shadow-2xl transition-all border border-white/20">
        <div className="relative z-10">
          <div className="flex justify-between items-start mb-6">
            <div className="flex-1">
              <p className="text-black/60 text-[10px] font-black mb-3 uppercase tracking-widest">وردك الحالي لهذا اليوم</p>
              <div className="space-y-2">
                <div className="flex items-center gap-3">
                   <span className="w-8 h-6 flex items-center justify-center text-[10px] bg-black/10 rounded-lg font-black text-black/60">من</span>
                   <div className="flex flex-col">
                      <h2 className="text-xl font-black text-black leading-none">{wirdInfo?.startSurah || '...'}</h2>
                      <span className="text-[9px] font-bold text-black/40 mt-1">آية {wirdInfo?.startAyah || '..'}</span>
                   </div>
                </div>
                <div className="flex items-center gap-3 mt-4">
                   <span className="w-8 h-6 flex items-center justify-center text-[10px] bg-black/10 rounded-lg font-black text-black/60">إلى</span>
                   <div className="flex flex-col">
                      <h2 className="text-xl font-black text-black leading-none">{wirdInfo?.endSurah || '...'}</h2>
                      <span className="text-[9px] font-bold text-black/40 mt-1">آية {wirdInfo?.endAyah || '..'}</span>
                   </div>
                </div>
              </div>
              <p className="mt-6 text-[10px] font-black opacity-40 tracking-widest text-black">المقرر: {userData.khatmah.pagesPerDay} صفحات</p>
            </div>
            <div className="w-16 h-16 rounded-full border-4 border-black/10 flex flex-col items-center justify-center bg-black/5">
              <span className="text-sm font-black text-black leading-none">{Math.round((userData.khatmah.currentPage / 604) * 100)}%</span>
              <span className="text-[7px] font-bold opacity-40 uppercase text-black">خاتمة</span>
            </div>
          </div>

          <div className="flex gap-3">
            <button 
              onClick={() => onWirdClick(userData.khatmah.currentPage)}
              className="flex-1 bg-black text-[var(--gold)] font-black py-4 rounded-2xl shadow-xl hover:bg-black/90 transition-all active:scale-95 text-xs flex items-center justify-center gap-2"
            >
              <span>متابعة القراءة (ص {userData.khatmah.currentPage})</span>
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" /></svg>
            </button>
            <button 
              onClick={advanceWird} 
              disabled={userData.khatmah.pagesPerDay === 0}
              className={`w-14 h-14 rounded-2xl flex items-center justify-center border transition-all active:scale-90 ${
                userData.khatmah.isCompletedToday 
                  ? 'bg-white border-white text-black shadow-[0_0_15px_rgba(255,255,255,0.4)]' 
                  : 'bg-black/10 border-black/10 text-black'
              } disabled:opacity-30 disabled:grayscale`}
              title="إتمام الورد"
            >
              {userData.khatmah.isCompletedToday ? (
                <div className="flex flex-col items-center">
                  <span className="text-lg font-black leading-none">+</span>
                  <span className="text-[6px] font-bold uppercase">التالي</span>
                </div>
              ) : (
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" /></svg>
              )}
            </button>
          </div>
        </div>
      </div>

      <div className={`glass-panel rounded-[2rem] p-6 flex justify-between items-center border border-[var(--border-color)] shadow-sm ${isDark ? 'bg-white/10 border-white/20' : ''}`}>
        <div>
          <p className={`text-[10px] font-black uppercase ${isDark ? 'text-white' : 'opacity-40'}`}>الصلاة القادمة</p>
          <h4 className="text-xl font-black">{nextPrayer?.name || '...'}</h4>
        </div>
        <div className="text-right">
          <p className="text-2xl font-black text-[var(--gold)]">{nextPrayer?.countdown || '--:--'}</p>
          <p className={`text-[10px] font-black ${isDark ? 'text-white' : 'opacity-40'}`}>الأذان {nextPrayer?.time || '--:--'}</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <button onClick={() => onNavigate('recitations')} className={`glass-panel rounded-[2rem] p-6 text-center border border-[var(--border-color)] hover:bg-[var(--gold)]/10 shadow-sm transition-all active:scale-95 flex flex-col items-center gap-2 ${isDark ? 'bg-white/10 border-white/20' : ''}`}>
          <h5 className="text-sm font-black">تلاوات خاشعة</h5>
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-[var(--gold)]" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3" /></svg>
        </button>
        <button onClick={() => onNavigate('minbar')} className={`glass-panel rounded-[2rem] p-6 text-center border border-[var(--border-color)] hover:bg-[var(--gold)]/10 shadow-sm transition-all active:scale-95 flex flex-col items-center gap-2 ${isDark ? 'bg-white/10 border-white/20' : ''}`}>
          <h5 className="text-sm font-black">المنبر الإسلامي</h5>
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-[var(--gold)]" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" /></svg>
        </button>
      </div>
    </div>
  );
};

export default Home;
