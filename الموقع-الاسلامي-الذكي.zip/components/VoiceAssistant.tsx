
import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI, Modality, Type, FunctionDeclaration, LiveServerMessage, Blob } from '@google/genai';

interface VoiceAssistantProps {
  isActive: boolean;
  setIsActive: (val: boolean) => void;
  onCommand?: (name: string, args?: any) => void;
}

function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

function encode(bytes: Uint8Array) {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

export default function VoiceAssistant({ isActive, setIsActive, onCommand }: VoiceAssistantProps) {
  const sessionRef = useRef<any>(null);
  const inputAudioContextRef = useRef<AudioContext | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const micStreamRef = useRef<MediaStream | null>(null);
  const isConnectingRef = useRef<boolean>(false);
  const retryCountRef = useRef<number>(0);

  useEffect(() => {
    if (isActive) {
      startSession();
    } else {
      stopSession();
    }
    return () => stopSession();
  }, [isActive]);

  const controlAppFunction: FunctionDeclaration = {
    name: 'control_app',
    parameters: {
      type: Type.OBJECT,
      description: 'التحكم الشامل في التطبيق: التنقل، تغيير المظهر، تشغيل التلاوات والخطب، أو الأذكار.',
      properties: {
        action: {
          type: Type.STRING,
          description: 'الإجراء المطلوب تنفيذه.',
        },
        target: {
          type: Type.STRING,
          description: 'الوجهة أو القسم المطلوب فتحه.',
        },
        theme: {
          type: Type.STRING,
          description: 'لون المظهر.',
        },
        page_number: {
          type: Type.NUMBER,
          description: 'رقم الصفحة في المصحف.',
        },
        surah_name: {
          type: Type.STRING,
          description: 'اسم السورة.',
        },
        azkar_category: {
          type: Type.STRING,
          description: 'نوع الأذكار.',
        },
        sheikh_id: {
          type: Type.STRING,
          description: 'معرف القارئ.',
        }
      },
      required: ['action'],
    },
  };

  const startSession = async () => {
    if (isConnectingRef.current) return;
    isConnectingRef.current = true;

    try {
      stopSession();
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      inputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      outputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      nextStartTimeRef.current = 0;

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      micStreamRef.current = stream;
      
      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            isConnectingRef.current = false;
            retryCountRef.current = 0;
            if (!inputAudioContextRef.current || !micStreamRef.current) return;
            const source = inputAudioContextRef.current.createMediaStreamSource(micStreamRef.current);
            const scriptProcessor = inputAudioContextRef.current.createScriptProcessor(4096, 1, 1);
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const int16 = new Int16Array(inputData.length);
              for (let i = 0; i < inputData.length; i++) int16[i] = inputData[i] * 32768;
              const pcmBlob: Blob = { data: encode(new Uint8Array(int16.buffer)), mimeType: 'audio/pcm;rate=16000' };
              // Always send input via sessionPromise to handle the connection race condition
              sessionPromise.then(s => { 
                if (s) s.sendRealtimeInput({ media: pcmBlob }); 
              }).catch(() => {});
            };
            source.connect(scriptProcessor);
            scriptProcessor.connect(inputAudioContextRef.current.destination);
          },
          onmessage: async (message: LiveServerMessage) => {
            // Handle interrupted message from model
            if (message.serverContent?.interrupted) {
              for (const source of sourcesRef.current) {
                try { source.stop(); } catch(e) {}
              }
              sourcesRef.current.clear();
              nextStartTimeRef.current = 0;
            }

            if (message.toolCall) {
              for (const fc of message.toolCall.functionCalls) {
                if (onCommand) await onCommand(fc.name, fc.args);
                // Fix: sendToolResponse expects functionResponses as a single object for a call response
                sessionPromise.then(s => s.sendToolResponse({
                  functionResponses: { id: fc.id, name: fc.name, response: { result: "ok_executed" } }
                }));
              }
            }
            
            // Extract audio data from the model's turn
            const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (base64Audio && outputAudioContextRef.current) {
              const ctx = outputAudioContextRef.current;
              if (ctx.state === 'suspended') await ctx.resume();
              
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
              const audioBuffer = await decodeAudioData(decode(base64Audio), ctx, 24000, 1);
              const source = ctx.createBufferSource();
              source.buffer = audioBuffer;
              source.connect(ctx.destination);
              
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += audioBuffer.duration;
              sourcesRef.current.add(source);
              source.onended = () => sourcesRef.current.delete(source);
            }
          },
          onclose: () => { isConnectingRef.current = false; setIsActive(false); },
          onerror: (e) => {
            console.error("Voice Error:", e);
            isConnectingRef.current = false;
            if (retryCountRef.current < 2 && isActive) {
              retryCountRef.current++;
              setTimeout(() => startSession(), 1000);
            } else {
              setIsActive(false);
            }
          },
        },
        config: {
          responseModalities: [Modality.AUDIO],
          tools: [{ functionDeclarations: [controlAppFunction] }],
          speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Puck' } } },
          systemInstruction: `أنت المساعد الصوتي لـ "Zikr". وظيفتك تنفيذ أوامر المستخدم فوراً.
          إذا طلب المستخدم أي قسم أو سورة أو أذكار، استخدم أداة control_app.
          كن لبقاً ومختصراً جداً في ردودك الصوتية.`,
        }
      });
      sessionRef.current = await sessionPromise;
    } catch (err) {
      isConnectingRef.current = false;
      setIsActive(false);
    }
  };

  const stopSession = () => {
    if (sessionRef.current) { try { sessionRef.current.close(); } catch(e) {} sessionRef.current = null; }
    if (micStreamRef.current) { micStreamRef.current.getTracks().forEach(t => t.stop()); micStreamRef.current = null; }
    if (inputAudioContextRef.current) { inputAudioContextRef.current.close().catch(() => {}); inputAudioContextRef.current = null; }
    if (outputAudioContextRef.current) { outputAudioContextRef.current.close().catch(() => {}); outputAudioContextRef.current = null; }
    sourcesRef.current.forEach(s => { try { s.stop(); } catch(e) {} });
    sourcesRef.current.clear();
    isConnectingRef.current = false;
  };

  return null;
}
