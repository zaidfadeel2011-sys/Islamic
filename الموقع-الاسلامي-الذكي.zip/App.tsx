
import React, { useState, useEffect } from 'react';
import { Page, UserData, PrayerTimings, CustomRecitation } from './types';
import Header from './components/Header';
import BottomNav from './components/BottomNav';
import Home from './components/Home';
import FatwaAssistant from './components/FatwaAssistant';
import PrayerTracker from './components/PrayerTracker';
import QuranReader, { SURAH_INDEX } from './components/QuranReader';
import Azkar from './components/Azkar';
import Settings from './components/Settings';
import Minbar from './components/Minbar';
import Recitations from './components/Recitations';
import VoiceAssistant from './components/VoiceAssistant';
import { fetchPrayerTimes } from './services/prayerService';

export const RECITATIONS_DATA: Record<string, CustomRecitation[]> = {
  nafees: [
    { id: 1, title: 'الفاتحة', url: 'https://youtu.be/hZwA9D2nDqM' },
    { id: 2, title: 'البقرة', url: 'https://youtu.be/9HW7j9lZZTU' },
    { id: 3, title: 'الكهف', url: 'https://youtu.be/-Rvavu8vyEw' },
    { id: 4, title: 'الدخان', url: 'https://youtu.be/0nKqbDR_ya0' },
    { id: 5, title: 'القيامة', url: 'https://youtu.be/WJ6OWeTTqtU' },
    { id: 6, title: 'الملك', url: 'https://youtu.be/Byyrubr7eqQ' }
  ],
  dosari: [
    { id: 7, title: 'الفاتحة', url: 'https://youtu.be/MePQ7B0dNek' },
    { id: 8, title: 'البقرة', url: 'https://youtu.be/P0uaLRO6V1U' },
    { id: 9, title: 'الكهف', url: 'https://youtu.be/GYqzkR_AnKE' },
    { id: 10, title: 'الدخان', url: 'https://youtu.be/zmarpXKqMno' },
    { id: 11, title: 'القيامة', url: 'https://youtu.be/Tj6M-QrsYWQ' },
    { id: 12, title: 'الملك', url: 'https://youtu.be/Xg3dnwXfsBc' }
  ],
  afasy: [
    { id: 13, title: 'الفاتحة', url: 'https://youtu.be/pUb9EW770d0' },
    { id: 14, title: 'البقرة', url: 'https://youtu.be/Y1M6hJHHrjM' },
    { id: 15, title: 'الكهف', url: 'https://youtu.be/fLHVCOLU_WI' },
    { id: 16, title: 'الدخان', url: 'https://youtu.be/ZB2Vaea3U6c' },
    { id: 17, title: 'القيامة', url: 'https://youtu.be/PUec_OAAsuw' },
    { id: 18, title: 'الملك', url: 'https://youtu.be/IDvV7Tvt8gM' }
  ]
};

export const SERMONS_DATA: CustomRecitation[] = [
  { id: 101, title: "التوبة النصوحة - الشيخ أحمد النفيس", url: "https://youtu.be/TTlnoFztl6E" },
  { id: 102, title: "كيف يغير القرآن نفوسنا - الشيخ أحمد النفيس", url: "https://youtu.be/AH7kbk9Smdk" },
  { id: 103, title: "صفة النار - الشيخ أحمد النفيس", url: "https://youtu.be/BV8JxZJZdIc" },
  { id: 104, title: "كيف كانت صلاتهم - الشيخ أحمد النفيس", url: "https://youtu.be/Ceti5Xc_oI0" },
  { id: 105, title: "متى نصر الله - الشيخ أحمد النفيس", url: "https://youtu.be/m-g98Rae79c" },
  { id: 106, title: "وقال ربكم ادعوني استجب لكم - الشيخ ياسر الدوسري", url: "https://youtu.be/FpIE8dmOSbU" },
  { id: 107, title: "مكارم الأخلاق - الشيخ ياسر الدوسري", url: "https://youtu.be/rjxrG2qVhYE" }
];

const STORAGE_KEY = 'zikr_user_data_v2';

const initialUserData: UserData = {
  username: "عبد الله",
  themeColor: 'white',
  prayerTable: {},
  customSurahsBySheikh: {},
  customSermons: [],
  azkarReminders: {},
  prayerReminders: {},
  fatwaHistory: [{
    role: 'assistant',
    content: 'أهلاً بك في مساعد Zikr الذكي. أنا هنا للإجابة على تساؤلاتك الفقهية والشرعية بكل إيجاز وموثوقية.'
  }],
  favorites: { surahIds: [], sheikhIds: [] },
  khatmah: {
    currentPage: 1,
    pagesPerDay: 5,
    lastReadDate: new Date().toDateString(),
    isCompletedToday: false,
    totalReadPages: 0
  }
};

const App: React.FC = () => {
  const [page, setPage] = useState<Page>('home');
  const [userData, setUserData] = useState<UserData>(initialUserData);
  const [prayerTimings, setPrayerTimings] = useState<PrayerTimings | null>(null);
  const [isVoiceActive, setIsVoiceActive] = useState(false);
  const [pendingAction, setPendingAction] = useState<CustomRecitation | null>(null);
  const [azkarCat, setAzkarCat] = useState<string | null>(null);
  const [isLoaded, setIsLoaded] = useState(false);
  
  const [quranNav, setQuranNav] = useState<{
    page: number | null, 
    ayah: number | null, 
    range: { from: number, to: number } | null
  }>({ page: null, ayah: null, range: null });

  const isDark = userData.themeColor === 'dark';

  useEffect(() => {
    const savedData = localStorage.getItem(STORAGE_KEY);
    if (savedData) {
      try {
        const parsed = JSON.parse(savedData);
        // Ensure new fields exist
        if (!parsed.fatwaHistory) parsed.fatwaHistory = initialUserData.fatwaHistory;
        setUserData(parsed);
      } catch (e) {
        console.error("Failed to load user data", e);
      }
    }
    setIsLoaded(true);

    navigator.geolocation.getCurrentPosition(
      (pos) => { fetchPrayerTimes(pos.coords.latitude, pos.coords.longitude).then(setPrayerTimings); },
      () => { fetchPrayerTimes(24.7136, 46.6753).then(setPrayerTimings); }
    );
  }, []);

  useEffect(() => {
    if (isLoaded) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(userData));
    }
  }, [userData, isLoaded]);

  const normalizeText = (text: string) => {
    return text.replace(/^سورة\s+/, "").replace(/^(ال)/, "").trim();
  };

  const handleVoiceCommand = async (name: string, args: any) => {
    if (name === 'control_app') {
      const { action, target, theme, page_number, surah_name, ayah_number, sheikh_id, sermon_title, azkar_category } = args;

      if (action === 'navigate') {
        if (target) setPage(target as Page);
        if (target === 'quran') {
          let targetPage = page_number;
          if (surah_name && !targetPage) {
            const cleanName = normalizeText(surah_name);
            const surah = SURAH_INDEX.find(s => normalizeText(s.name).includes(cleanName));
            if (surah) targetPage = surah.start;
          }
          setQuranNav({ page: targetPage || null, ayah: ayah_number || null, range: null });
        }
        if (target === 'azkar' && azkar_category) {
          setAzkarCat(azkar_category);
        }
      } else if (action === 'change_theme' && theme) {
        setUserData(prev => ({ ...prev, themeColor: theme as any }));
      } else if (action === 'play_recitation') {
        setPage('recitations');
        const sid = sheikh_id || 'nafees';
        const cleanSurah = normalizeText(surah_name || "");
        if (RECITATIONS_DATA[sid]) {
          const match = RECITATIONS_DATA[sid].find(r => normalizeText(r.title).includes(cleanSurah));
          if (match) setPendingAction(match);
        }
      } else if (action === 'play_sermon') {
        setPage('minbar');
        const cleanSermon = normalizeText(sermon_title || surah_name || "");
        const match = SERMONS_DATA.find(s => normalizeText(s.title).includes(cleanSermon));
        if (match) setPendingAction(match);
      } else if (action === 'search_ayah') {
        setPage('quran');
        let targetPage = page_number;
        if (surah_name && !targetPage) {
            const cleanName = normalizeText(surah_name);
            const surah = SURAH_INDEX.find(s => normalizeText(s.name).includes(cleanName));
            if (surah) targetPage = surah.start;
        }
        setQuranNav({ page: targetPage || null, ayah: ayah_number || null, range: null });
      }
    }
  };

  if (!isLoaded) return null;

  return (
    <div className={`min-h-screen transition-colors duration-500 pb-32 pt-24 px-6 ${isDark ? 'bg-[#0a0a0a] text-white' : 'bg-[#fafafa] text-black'}`}>
      <Header userData={userData} onSettings={() => setPage('settings')} isVoiceActive={isVoiceActive} setIsActive={setIsVoiceActive} />
      
      {pendingAction && (
        <div className="fixed inset-0 z-[100] bg-black/60 backdrop-blur-sm flex items-center justify-center p-6">
          <div className="glass-panel p-8 rounded-[2.5rem] border-2 border-[var(--gold)]/30 max-w-sm w-full text-center shadow-2xl animate-in zoom-in-95 duration-300">
            <div className="w-16 h-16 bg-[var(--gold)]/20 rounded-full flex items-center justify-center mx-auto mb-4 text-[var(--gold)]">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" /></svg>
            </div>
            <h3 className="text-xl font-black mb-2">هل تريد تشغيل:</h3>
            <p className="text-[var(--gold)] font-bold mb-6">{pendingAction.title}</p>
            <div className="flex gap-3">
              <button 
                onClick={() => { 
                  if (pendingAction.url.startsWith('data:')) {
                    const win = window.open();
                    win?.document.write(`<audio controls autoplay style="width:100%"><source src="${pendingAction.url}" type="audio/mpeg"></audio>`);
                  } else {
                    window.open(pendingAction.url, '_blank'); 
                  }
                  setPendingAction(null); 
                }}
                className="flex-1 bg-[var(--gold)] text-black font-black py-4 rounded-2xl shadow-lg active:scale-95"
              >
                تشغيل الآن
              </button>
              <button 
                onClick={() => setPendingAction(null)}
                className="flex-1 bg-black/10 py-4 rounded-2xl font-black active:scale-95"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}

      <main className="max-w-2xl mx-auto">
        {page === 'home' && <Home userData={userData} setUserData={setUserData} prayerTimings={prayerTimings} onNavigate={setPage} onWirdClick={(p) => { setPage('quran'); setQuranNav({page: p, ayah: null, range: null}); }} />}
        {page === 'quran' && <QuranReader userData={userData} setUserData={setUserData} initialPage={quranNav.page} targetAyah={quranNav.ayah} initialRange={quranNav.range} />}
        {page === 'prayer' && <PrayerTracker prayerTimings={prayerTimings} />}
        {page === 'fatwa' && <FatwaAssistant userData={userData} setUserData={setUserData} />}
        {page === 'azkar' && <Azkar initialCategory={azkarCat} command={null} onCommandProcessed={() => setAzkarCat(null)} isDark={isDark} />}
        {page === 'settings' && <Settings userData={userData} setUserData={setUserData} onNavigate={setPage} />}
        {page === 'minbar' && <Minbar userData={userData} setUserData={setUserData} />}
        {page === 'recitations' && <Recitations userData={userData} setUserData={setUserData} />}
      </main>
      <VoiceAssistant isActive={isVoiceActive} setIsActive={setIsVoiceActive} onCommand={handleVoiceCommand} />
      <BottomNav currentPage={page} onNavigate={setPage} />
    </div>
  );
};

export default App;
